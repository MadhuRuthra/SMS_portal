/*
Routes are used in direct incoming API requests to backend resources.
It defines how our application should handle all the HTTP requests by the client.
This page is used to routing the logout.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const express = require("express");
const router = express.Router();
// Import the Logout functions page
const Logout = require("./logout");
require("dotenv").config();
const jwt = require('jsonwebtoken');
// Import the default validation middleware
const validator = require('../validation/middleware')
const valid_user = require("../validation/valid_user_middleware");
// Import the validation page
const LogoutValidation = require("../validation/logout_validation");
const main = require('../logger');
const db = require("../db_connect/connect");

// logout function - start
router.post(
  "/",
  validator.body(LogoutValidation),
  valid_user,
    async function (req, res, next) {
      try {
        const logger = main.logger
        const logger_all = main.logger_all
  
        const result = await Logout.logout(req);
        result['request_id'] = req.body.request_id;
  
        logger.info("[API RESPONSE] " + JSON.stringify(result))
  
        if (result.response_code == 0) {
          logger_all.info("[update query request] : " + `UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP,response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
          const update_api_log = await db.query(`UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP,response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
          logger_all.info("[update query response] : " + JSON.stringify(update_api_log))
        }
        else {
          logger_all.info("[update query request] : " + `UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP,response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
          const update_api_log = await db.query(`UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP,response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
          logger_all.info("[update query response] : " + JSON.stringify(update_api_log))
        }
        res.json(result);
      } catch (err) {
        console.error(`Error while getting data`, err.message);
        next(err);
      }
    }
  );
// logout function - end
module.exports = router;
