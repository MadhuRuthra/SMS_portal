/*
This api has chat API functions which is used to connect the mobile chat.
This page is act as a Backend page which is connect with Node JS API and PHP Frontend.
It will collect the form details and send it to API.
After get the response from API, send it back to Frontend.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const db = require("../../db_connect/connect");
require("dotenv").config();
const main = require('../../logger');
// WebAnnouncement - start
async function WebAnnouncement(req) {
	const logger_all = main.logger_all
	const logger = main.logger
	try {


		// query parameters
		logger_all.info("[WebAnnouncement query parameters] : " + JSON.stringify(req.body));

		// to get the web_announcement details
		const get_web_announcement = `SELECT * FROM web_announcement ORDER BY announcement_id Desc`;

		logger_all.info("[select query request] : " + get_web_announcement);
		const get_web_announcement_list = await db.query(get_web_announcement);

		logger_all.info("[select query response] : " + JSON.stringify(get_web_announcement_list))

		// if the web_announcement length is coming to get the web_announcement details.otherwise to send the no data available message.
		if (get_web_announcement_list.length == 0) {
			return { response_code: 0, response_status: 204, response_msg: 'No data available' };
		}
		else {
			return { response_code: 1, response_status: 200, num_of_rows: get_web_announcement_list.length, response_msg: 'Success', result: get_web_announcement_list, num_of_rows: get_web_announcement_list.length };
		}
	}
	catch (e) {// any error occurres send error response to client
		logger_all.info("[WebAnnouncement failed response] : " + e)
		return { response_code: 0, response_status: 201, response_msg: 'Error occured' };
	}
}
// 	WebAnnouncement - end

// using for module exporting
module.exports = {
	WebAnnouncement
}