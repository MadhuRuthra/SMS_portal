/*
This api has chat API functions which is used to connect the mobile chat.
This page is act as a Backend page which is connect with Node JS API and PHP Frontend.
It will collect the form details and send it to API.
After Update the response from API, send it back to Frontend.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const db = require("../../db_connect/connect");
require("dotenv").config();
const main = require('../../logger');
// UpdateWebAnnouncement - start
async function UpdateWebAnnouncement(req) {
	const logger_all = main.logger_all
	const logger = main.logger
	try {

		const announcement_msg = req.body.announcement_msg;
		const announcement_id = req.body.announcement_id;
		const announcement_status = req.body.announcement_status;
		const announcement_expirydt = req.body.announcement_expirydt;
		let update_web_announcement;
		// query parameters
		logger_all.info("[UpdateWebAnnouncement query parameters] : " + JSON.stringify(req.body));

		if (announcement_expirydt) {
			// to Update the web_announcement details
			update_web_announcement = `Update web_announcement set announcement_msg = '${announcement_msg}', announcement_status = '${announcement_status}', announcement_expirydt = '${announcement_expirydt}' WHERE announcement_id = '${announcement_id}'`;
		} else {
			// to Update the web_announcement details
			update_web_announcement = `Update web_announcement set announcement_msg = '${announcement_msg}', announcement_status = '${announcement_status}' WHERE announcement_id = '${announcement_id}'`;
		}

		logger_all.info("[select query request] : " + update_web_announcement);
		const update_web_announcement_list = await db.query(update_web_announcement);

		logger_all.info("[select query response] : " + JSON.stringify(update_web_announcement_list))

		// if the web_announcement length is coming to Update the web_announcement details.otherwise to send the no data available message.
		if (update_web_announcement_list.affectedRows == 0) {
			return { response_code: 0, response_status: 204, response_msg: 'No data available' };
		}
		else {
			return { response_code: 1, response_status: 200, response_msg: 'Success' };
		}
	}
	catch (e) {// any error occurres send error response to client
		logger_all.info("[UpdateWebAnnouncement failed response] : " + e)
		return { response_code: 0, response_status: 201, response_msg: 'Error occured' };
	}
}
// 	UpdateWebAnnouncement - end

// using for module exporting
module.exports = {
	UpdateWebAnnouncement
}