/*
This api has dashboard API functions which is used to routing the dashboard.
This page is used to create the url for dashboard API functions.
It will be used to run the dashboard process to check and the connect database to get the response for this function.
After get the response from API, send it back to callfunctions.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const express = require("express");
const router = express.Router();
require("dotenv").config();
const db = require("../../db_connect/connect");

// Import the list functions page
const View_Web_Announcement = require("./view_webannouncement");
const Web_Announcement = require("./web_announcement_list");
const Create_Web_Announcement = require("./create_webannouncement");
const Update_Web_Announcement = require("./update_webannouncement");

// Import the validation page
const  AnnouncementValidation = require("../../validation/webannouncement_validation");
const ViewAnnouncementValidation = require("../../validation/view_announcementvalidation");
const CommonValidation = require("../../validation/common_validation");
const valid_user_reqID = require("../../validation/valid_user_middleware_reqID");

// Import the default validation middleware
const validator = require('../../validation/middleware')
const valid_user = require("../../validation/valid_user_middleware");
const main = require('../../logger');

// ViewWebAnnouncement -start
router.get(
  "/viewwebannouncement",
  validator.body(ViewAnnouncementValidation),
  async function (req, res, next) {
    try {// access the CountryList function
      const logger = main.logger
      const result = await View_Web_Announcement.ViewWebAnnouncement(req);

      // logger.info("[API RESPONSE] " + JSON.stringify(result))

      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// ViewWebAnnouncement -end

// Web_Announcement -start
router.get(
  "/webannouncement_list",
  validator.body(CommonValidation),
  async function (req, res, next) {
    try {// access the CountryList function
      const logger = main.logger
      const result = await Web_Announcement.WebAnnouncement(req);

      // logger.info("[API RESPONSE] " + JSON.stringify(result))

      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// Web_Announcement -end

// Create Web_Announcement -start
router.post(
  "/create_webannouncement",
  validator.body(AnnouncementValidation),
  valid_user_reqID,
  async function (req, res, next) {
    try {// access the ChangePassword function
      const logger = main.logger

      const logger_all = main.logger_all;

      const result = await Create_Web_Announcement.CreateWebAnnouncement(req);

      result['request_id'] = req.body.request_id;

      //update api log for failure response
      if (result.response_code == 0) {
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }
      else {
        //Otherwise update api log with success response
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }

      logger.info("[API RESPONSE] " + JSON.stringify(result))
      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// Create Web_Announcement -end


// Update Web_Announcement -start
router.put(
  "/update_webannouncement",
  validator.body(AnnouncementValidation),
  valid_user_reqID,
  async function (req, res, next) {
    try {// access the ChangePassword function
      const logger = main.logger

      const logger_all = main.logger_all;

      const result = await Update_Web_Announcement.UpdateWebAnnouncement(req);

      result['request_id'] = req.body.request_id;

      //update api log for failure response
      if (result.response_code == 0) {
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }
      else {
        //Otherwise update api log with success response
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }

      logger.info("[API RESPONSE] " + JSON.stringify(result))
      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// Update Web_Announcement -end
module.exports = router;
