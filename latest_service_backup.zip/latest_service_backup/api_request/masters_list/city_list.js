/*
This api has chat API functions which is used to connect the mobile chat.
This page is act as a Backend page which is connect with Node JS API and PHP Frontend.
It will collect the form details and send it to API.
After get the response from API, send it back to Frontend.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const db = require("../../db_connect/connect");
require("dotenv").config();
const main = require('../../logger');
// CityList - start
async function CityList(req) {
	const logger_all = main.logger_all
	const logger = main.logger
	try {

		// get body values
		const state_id = req.body.state_id;

		// query parameters
		logger_all.info("[CityList query parameters] : " + JSON.stringify(req.body));

		// to get the master_countries details
		const get_states = `SELECT * FROM master_cities WHERE state_id = '${state_id}' ORDER BY name Asc`;
		// const get_states = `SELECT * FROM master_cities ORDER BY name Asc`;


		logger_all.info("[select query request] : " + get_states);
		const get_city_list = await db.query(get_states);
		// logger_all.info("[select query response] : " + JSON.stringify(get_city_list))
		// if the master_countries length is coming to get the master_countries details.otherwise to send the no data available message.
		if (get_city_list.length == 0) {
			return { response_code: 0, response_status: 204, response_msg: 'No data available' };
		}
		else {
			return { response_code: 1, response_status: 200, num_of_rows: get_city_list.length, response_msg: 'Success', result: get_city_list };
		}
	}
	catch (e) {// any error occurres send error response to client
		logger_all.info("[CityList failed response] : " + e)
		return { response_code: 0, response_status: 201, response_msg: 'Error occured' };
	}
}
// 	CityList - end

// using for module exporting
module.exports = {
	CityList
}