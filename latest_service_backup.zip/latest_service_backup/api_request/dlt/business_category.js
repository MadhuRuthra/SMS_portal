/*
This api has chat API functions which is used to connect the mobile chat.
This page is act as a Backend page which is connect with Node JS API and PHP Frontend.
It will collect the form details and send it to API.
After get the response from API, send it back to Frontend.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const db = require("../../db_connect/connect");
require("dotenv").config();
const main = require('../../logger');
// BusinessCategory - start
async function BusinessCategory(req) {
	const logger_all = main.logger_all
	const logger = main.logger
	try {

		// query parameters
		logger_all.info("[BusinessCategory query parameters] : " + JSON.stringify(req.body));

		// to get the master_countries details
		const get_users = `SELECT * FROM sender_business_category where business_category_status = 'Y'ORDER BY sender_buscategory_id Asc`;

		logger_all.info("[select query request] : " + get_users);
		const get_users_list = await db.query(get_users);
        
		logger_all.info("[select query response] : " + JSON.stringify(get_users_list))

		// if the master_countries length is coming to get the master_countries details.otherwise to send the no data available message.
		if (get_users_list.length == 0) {
			return { response_code: 0, response_status: 204, response_msg: 'No data available' };
		}
		else {
			return { response_code: 1, response_status: 200, num_of_rows: get_users_list.length, response_msg: 'Success', result: get_users_list,num_of_rows: get_users_list.length };
		}
	}
	catch (e) {// any error occurres send error response to client
		logger_all.info("[BusinessCategory failed response] : " + e)
		return { response_code: 0, response_status: 201, response_msg: 'Error occured' };
	}
}
// 	BusinessCategory - end

// using for module exporting
module.exports = {
	BusinessCategory
}