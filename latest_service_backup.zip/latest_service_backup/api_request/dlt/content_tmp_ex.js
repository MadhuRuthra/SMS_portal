/*
This api has chat API functions which is used to connect the mobile chat.
This page is act as a Backend page which is connect with Node JS API and PHP Frontend.
It will collect the form details and send it to API.
After get the response from API, send it back to Frontend.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const db = require("../../db_connect/connect");
require("dotenv").config();
const main = require('../../logger');
const nodemailer = require('nodemailer');

// DLT_Sender_Existing - start
async function DLT_Sender_Existing(req) {
    const logger_all = main.logger_all
    const logger = main.logger
    try {

        // get body values
        const user_id = req.body.user_id;
        const header_sender_id = req.body.header_sender_id;
        const slt_operator = req.body.slt_operator;
        const slt_template_type = req.body.slt_template_type;
        const slt_business_category = req.body.slt_business_category;
        const txt_explanation = req.body.txt_explanation;
        const file_name = req.body.file_name;
        const file_name_1 = req.body.file_name_1;
        const ex_new_senderid = req.body.ex_new_senderid;
        const txt_constempname = req.body.txt_constempname;
        const txt_consmsg = req.body.txt_consmsg;
        const txt_consbrndname = req.body.txt_consbrndname;
        const dlt_process = req.body.dlt_process;
        let display_business;

        // query parameters
        logger_all.info("[DLT_Sender_Existing query parameters] : " + JSON.stringify(req.body));

        // to get the user details
        const get_user = `SELECT * FROM user_management where user_id = '${user_id}'`;

        logger_all.info("[select query request] : " + get_user);
        const get_user_result = await db.query(get_user);

        logger_all.info("[select query response] : " + JSON.stringify(get_user_result))

        const user_name = get_user_result[0].user_name;

        // to get the master_countries details
        const get_users = `SELECT * FROM cm_senderid where sender_title = '${header_sender_id}'`;

        logger_all.info("[select query request] : " + get_users);
        const get_users_list = await db.query(get_users);

        logger_all.info("[select query response] : " + JSON.stringify(get_users_list))

        // if the master_countries length is coming to get the master_countries details.otherwise to send the no data available message.
        if (get_users_list.length == 0) {
            return { response_code: 0, response_status: 204, response_msg: 'This Title already used. Kindly try with some others!!' };
        }
        else {

            // to insert the web_announcement details
            const insert_cm_senderid = `INSERT INTO cm_senderid VALUES(NULL, '${user_id}', '${slt_operator}', '${slt_template_type}','${slt_business_category}','${header_sender_id}','${txt_explanation}','${file_name}','W',CURRENT_TIMESTAMP, NULL, NULL, NULL, NULL,'${ex_new_senderid}','${dlt_process}',NULL)`;

            logger_all.info("[insert query request] : " + insert_cm_senderid);
            const insert_result = await db.query(insert_cm_senderid);

            logger_all.info("[insert query response] : " + JSON.stringify(insert_result))

            const last_cm_insertid = insert_result.insertId;
            if (insert_result.affectedRows > 0) {

                const insert_cm_consenttmp = `INSERT INTO cm_consent_template VALUES(NULL, '${last_cm_insertid}', '${user_id}', '${txt_constempname}','${txt_consbrndname}','${txt_consmsg}','${file_name_1}','W',CURRENT_TIMESTAMP, NULL, NULL, NULL)`;

                logger_all.info("[insert query request] : " + insert_cm_consenttmp);
                const insert_result_1 = await db.query(insert_cm_consenttmp);

                logger_all.info("[insert query response] : " + JSON.stringify(insert_result_1))

                if (insert_result_1.affectedRows > 0) {

                    const slt_business = `SELECT * FROM sender_business_category where business_category_status = 'Y' and sender_buscategory_id = '${slt_business_category}' ORDER BY sender_buscategory_id Asc`;

                    logger_all.info("[insert query request] : " + slt_business);
                    const slt_business_result = await db.query(slt_business);

                    logger_all.info("[insert query response] : " + JSON.stringify(slt_business_result))
                    if (slt_business_result.length) {
                        display_business = slt_business_result[0].business_category;
                    }
                    // Assuming you have the file paths stored in variables
                    const filePath1 = path.join(__dirname, 'opt/lampp/htdocs/uploads/license/'.file_name); // Replace with your file path
                    const filePath2 = path.join(__dirname, 'opt/lampp/htdocs/uploads/consent/'.file_name_1); // Replace with your file path


                    const transporter = nodemailer.createTransport({
                        service: 'gmail',
                        auth: {
                            user: 'suhasini.r@yeejai.com', // Your email address
                            pass: 'cicauzxsnivlvhvs' // Your email password or app-specific password
                        }
                    });

                    const mailOptions = {
                        from: 'suhasini.r@yeejai.com', // Sender's email address and name
                        to: user_emailid, // Recipient's email addresses separated by commas
                        subject: 'New Sender ID Creation -"' + header_sender_id + 'for Simply Reach Reg ', // Email subject
                        text: `Dear Admin,\n\nCreated User : ${user_name}\nHeader Type : ${slt_template_type}\n Business Category : ${display_business}\n New Sender ID : ${header_sender_id} \n Explanation : ${txt_explanation} \n\n\n By,\n\n\n Simply Reach Team`,
                        attachments: [
                            {
                                filename: file_name, // Replace with the desired filename
                                path: filePath1 // Path to the file
                            },
                            {
                                filename: file_name_1, // Replace with the desired filename
                                path: filePath2 // Path to the file
                            }
                        ]
                    };

                    return new Promise((resolve, reject) => {
                        transporter.sendMail(mailOptions, async (error, info) => {
                            if (error) {
                                logger_all.info('Error occurred: Mail cannot be sent. Kindly check!!', error);
                                return resolve({ response_code: 0, response_status: 201, response_msg: 'Mail cannot be sent. Kindly check!!' });
                            } else {
                                logger_all.info('Email sent: New password sent to your email. Kindly verify!!', info.response);

                                return { response_code: 1, response_status: 200, response_msg: 'Success' };
                            }
                        });
                    });
                }
            }
        }
    }
    catch (e) {// any error occurres send error response to client
        logger_all.info("[DLT_Sender_Existing failed response] : " + e)
        return { response_code: 0, response_status: 201, response_msg: 'Error occured' };
    }
}
// 	DLT_Sender_Existing - end

// using for module exporting
module.exports = {
    DLT_Sender_Existing
}