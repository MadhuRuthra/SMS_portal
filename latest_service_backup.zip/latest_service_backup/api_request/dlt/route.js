/*
This api has dashboard API functions which is used to routing the dashboard.
This page is used to create the url for dashboard API functions .
It will be used to run the dashboard process to check and the connect database to get the response for this function.
After get the response from API, send it back to callfunctions.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const express = require("express");
const router = express.Router();

require("dotenv").config();
const fs = require('fs');
const db = require("../../db_connect/connect");
const path = require('path');

// Import the list functions page
const Message_Type = require("./message_type");
const Business_Category = require("./business_category");
const Dlt_new_sender = require("./create_newdlt_sender");
const Dlt_ex_sender = require("./create_exdlt_sender");
const Content_tmp_ex = require("./content_tmp_ex");
const Content_tmp_new = require("./content_tmp_new");

// Import the validation page
const Common_validation = require("../../validation/common_validation");
const valid_user_reqID = require("../../validation/valid_user_middleware_reqID");

// Import the default validation middleware
const validator = require('../../validation/middleware')
const valid_user = require("../../validation/valid_user_middleware");
const main = require('../../logger');

// MessageType -start
router.get(
  "/message_type",
  validator.body(Common_validation),
  async function (req, res, next) {
    try {// access the CountryList function
      const logger = main.logger
      const result = await Message_Type.MessageType(req);

      // logger.info("[API RESPONSE] " + JSON.stringify(result))

      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// MessageType -end


// Business Category -start
router.get(
  "/business_category",
  validator.body(Common_validation),
  async function (req, res, next) {
    try {// access the CountryList function
      const logger = main.logger
      const result = await Business_Category.BusinessCategory(req);

      // logger.info("[API RESPONSE] " + JSON.stringify(result))

      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// MessageType -end

// Create DLT SenderId New -start
router.post(
  "/dlt_senderid_new",
  // validator.body(AnnouncementValidation),
  valid_user_reqID,
  async function (req, res, next) {
    try {// access the ChangePassword function
      const logger = main.logger

      const logger_all = main.logger_all;

      const result = await Dlt_new_sender.DLT_SENDER_NEW(req);

      result['request_id'] = req.body.request_id;

      //update api log for failure response
      if (result.response_code == 0) {
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }
      else {
        //Otherwise update api log with success response
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }

      logger.info("[API RESPONSE] " + JSON.stringify(result))
      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// Create DLT SenderId New -end

// Create DLT SenderId Ex -start
router.post(
  "/dlt_senderid_ex",
  // validator.body(AnnouncementValidation),
  valid_user_reqID,
  async function (req, res, next) {
    try {// access the ChangePassword function
      const logger = main.logger

      const logger_all = main.logger_all;

      const result = await Create_Web_Announcement.CreateWebAnnouncement(req);

      result['request_id'] = req.body.request_id;

      //update api log for failure response
      if (result.response_code == 0) {
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }
      else {
        //Otherwise update api log with success response
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }

      logger.info("[API RESPONSE] " + JSON.stringify(result))
      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// Create DLT SenderId Ex -end

// Content Template New -start
router.post(
  "/content_tmp_new",
  // validator.body(AnnouncementValidation),
  valid_user_reqID,
  async function (req, res, next) {
    try {// access the ChangePassword function
      const logger = main.logger

      const logger_all = main.logger_all;

      const result = await Create_Web_Announcement.CreateWebAnnouncement(req);

      result['request_id'] = req.body.request_id;

      //update api log for failure response
      if (result.response_code == 0) {
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }
      else {
        //Otherwise update api log with success response
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }

      logger.info("[API RESPONSE] " + JSON.stringify(result))
      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// Content Template New - end 

// Content Template Ex -start
router.post(
  "/content_tmp_ex",
  // validator.body(AnnouncementValidation),
  valid_user_reqID,
  async function (req, res, next) {
    try {// access the ChangePassword function
      const logger = main.logger

      const logger_all = main.logger_all;

      const result = await Create_Web_Announcement.CreateWebAnnouncement(req);

      result['request_id'] = req.body.request_id;

      //update api log for failure response
      if (result.response_code == 0) {
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }
      else {
        //Otherwise update api log with success response
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }

      logger.info("[API RESPONSE] " + JSON.stringify(result))
      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// Content Template Ex - END
module.exports = router;
