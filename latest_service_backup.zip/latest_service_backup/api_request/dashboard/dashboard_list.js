/*
API that allows your frontend to communicate with your backend server (Node.js) for processing and retrieving data.
To access a MySQL database with Node.js and can be use it.
This page is used in dashboard functions which is used to get the dashboard details.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
const db = require("../../db_connect/connect");
require('dotenv').config()
const main = require('../../logger');
// dashboard otp Function - start
async function Dash_Board(req) {
    const logger_all = main.logger_all
    const logger = main.logger
    try {

        // Get all the req data
        const user_id = req.body.user_id;
        let total_response = []

        // query parameters
        logger_all.info("[Dashboard query parameters] : " + JSON.stringify(req.body));

        //    get admin dashboard
        const active_users = `SELECT * FROM admin_dashboard where admin_dash_status = 'Y' and user_id = '${user_id}'`
        logger_all.info("[select query request] : " + active_users);
        const active_users_result = await db.query(active_users);
        logger_all.info("[select query response] : " + JSON.stringify(active_users_result))
        total_response.push(active_users_result);

        //    get web_announcement details
        let get_announcement = `SELECT announcement_msg FROM web_announcement where announcement_status = \'Y\' and announcement_expirydt >= NOW()`;
        logger_all.info("[select query request] : " + get_announcement);
        let get_announcement_result = await db.query(get_announcement);
        logger_all.info("[select query response] : " + JSON.stringify(get_announcement_result))
        total_response.push(get_announcement_result);

        //    get one week datas
        const total_week_data = `SELECT count(sms.compose_sms_id) cntsms FROM compose_sms sms left JOIN compose_sms_content scon on sms.compose_sms_id = scon.compose_sms_id left JOIN compose_sms_status stat on sms.compose_sms_id = stat.compose_sms_id and stat.comsms_status = 'Y' where sms.user_id = '${user_id}' and sms.sms_status in ('Y', 'S') and (date(sms.sms_entry_date) BETWEEN DATE_ADD(NOW(), INTERVAL -7 DAY) AND NOW()) GROUP BY stat.comsms_status order by stat.comsms_status`;
        logger_all.info("[select query request] : " + total_week_data);
        const total_week_data_result = await db.query(total_week_data);
        logger_all.info("[select query response] : " + JSON.stringify(total_week_data_result))
        total_response.push(total_week_data_result);

        //    get one month datas
        const total_month_data = `SELECT smsrt.sms_route_id smrtid,smsrt.sms_route_title,crdbt.usrcrdbt_id,crdbt.sms_route_id crrtid, crdbt.user_id, crdbt.parent_id, crdbt.expiry_date, crdbt.valdity_period, crdbt.allot_sms, crdbt.per_sms_price, crdbt.usrcrdbt_status, crdbt.usrcrdbt_entry_date, usr.user_id, usr.user_name, crdbt.usrcrdbt_comments FROM sms_route_master smsrt right join user_credit_debit_account crdbt on smsrt.sms_route_id = crdbt.sms_route_id and (user_id = '${user_id}' or parent_id = '${user_id}')and (date(crdbt.usrcrdbt_entry_date)BETWEEN DATE_ADD(NOW(), INTERVAL -30 DAY) AND NOW()) left JOIN user_management usr on usr.user_id = crdbt.user_id where smsrt.sms_route_status = 'Y' ORDER BY smsrt.sms_route_id asc`;
        logger_all.info("[select query request] : " + total_month_data);
        const total_month_data_result = await db.query(total_month_data);
        logger_all.info("[select query response] : " + JSON.stringify(total_month_data_result))
        total_response.push(total_month_data_result);
        // get transaction datas

        const transaction_data = `SELECT usrm.user_id, usrm.user_name,rout.sms_route_id, rout.sms_route_title, rout.sms_route_desc, csnd.cm_sender_id,csnd.sender_title, ccnt.cm_content_tmplid,ccnt.cn_template_name, csms.mobile_nos,csms.sms_file, csms.sms_type, csnd.sender_temptype, ccnt.cn_template_name, csms.sms_status, csms.sms_entry_date,csms.new_hdsndrid, csms.new_cntmplid FROM compose_sms csms LEFT JOIN user_management usrm on usrm.user_id = csms.user_id LEFT JOIN sms_route_master rout on rout.sms_route_id = csms.sms_route_id LEFT JOIN cm_senderid csnd on csnd.cm_sender_id = csms.sender_header_id LEFT JOIN cm_content_template ccnt on ccnt.cm_content_tmplid = csms.dlt_template_id where csms.user_id = '${user_id}' order by csms.compose_sms_id desc limit 3`;
        logger_all.info("[select query request] : " + transaction_data);
        const transaction_data_result = await db.query(transaction_data);
        logger_all.info("[select query response] : " + JSON.stringify(transaction_data_result))
        total_response.push(transaction_data_result);

        // if the get total response length is not available to send the no available data.otherwise it will be return the total_response dashboard today details.
        if (total_response.length > 0) {
            return {
                response_code: 1, response_status: 200, response_msg: 'Success', num_of_rows: total_response.length, report: total_response
            };
        } else {
            return { response_code: 0, response_status: 204, response_msg: 'No Data Available' };
        }
    }
    // any error occurres send error response to client
    catch (e) {
        logger_all.info("[DashBoard OTP failed response] : " + e)
        return { response_code: 0, response_status: 201, response_msg: 'Error occured' };
    }
}
// Dash_Board - end

// using for module exporting
module.exports = {
    Dash_Board,
};
