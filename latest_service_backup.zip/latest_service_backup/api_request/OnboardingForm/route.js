/*
This api has dashboard API functions which is used to routing the dashboard.
This page is used to create the url for dashboard API functions.
It will be used to run the dashboard process to check and the connect database to get the response for this function.
After get the response from API, send it back to callfunctions.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const express = require("express");
const router = express.Router();
require("dotenv").config();
const db = require("../../db_connect/connect");

// Import the list functions page
const GetUserDetails = require("./get_user_details");
const CheckUserStatus = require("./check_user_status"); 
const Update_On_Boarding = require("./update_profile");
const Update_logo_change = require("./update_logo_change");
const OnboardingApprovalList = require("./onboarding_approval_list");
const Update_Status = require("./update_user_status");

// Import the validation page
const CommonValidation = require("../../validation/common_validation");
const Check_status_validation = require("../../validation/check_status_validation");
const GetUserDetailsValidation = require("../../validation/get_user_details_validation");
const UpdateonboardingValidation = require("../../validation/update_onboarding_validation");
const UpdateLogoValidation = require("../../validation/update_onboarding_validation");
const UpdateUserStatusValidation = require("../../validation/update_userstatus_validation");
const valid_user_reqID = require("../../validation/valid_user_middleware_reqID");


// Import the default validation middleware
const validator = require('../../validation/middleware')
const valid_user = require("../../validation/valid_user_middleware");
const main = require('../../logger');

// ViewWebAnnouncement -start
router.get(
  "/get_user_details",
  validator.body(GetUserDetailsValidation),
  async function (req, res, next) {
    try {// access the CountryList function
      const logger = main.logger
      const result = await GetUserDetails.Get_User_Details(req);

      // logger.info("[API RESPONSE] " + JSON.stringify(result))

      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// ViewWebAnnouncement -end

// CheckUserDetails -start
router.get(
  "/check_user_status",
  validator.body(Check_status_validation),
  async function (req, res, next) {
    try {// access the CountryList function
      const logger = main.logger
      const result = await CheckUserStatus.CheckUserDetails(req);

      // logger.info("[API RESPONSE] " + JSON.stringify(result))

      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// CheckUserDetails -end

// Onboaridng Approval list -start
router.get(
  "/onboarding_approval_list",
  valid_user,
  validator.body(CommonValidation),
  async function (req, res, next) {
    try {// access the Onboaridng Approval list function
      const logger = main.logger
      const result = await OnboardingApprovalList.onboarding_form_list(req);

      // logger.info("[API RESPONSE] " + JSON.stringify(result))

      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// Onboaridng Approval list -end    

// Update On Boarding -start
router.put(
  "/update_onboarding",
  validator.body(UpdateonboardingValidation),
  valid_user_reqID,
  async function (req, res, next) {
    try {// access the ChangePassword function
      const logger = main.logger

      const logger_all = main.logger_all;

      const result = await Update_On_Boarding.UpdateOnBoarding(req);

      result['request_id'] = req.body.request_id;

      //update api log for failure response
      if (result.response_code == 0) {
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }
      else {
        //Otherwise update api log with success response
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }

      logger.info("[API RESPONSE] " + JSON.stringify(result))
      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// Update On Boarding - end

// Update On Boarding -start
router.put(
  "/update_logo",
  validator.body(UpdateLogoValidation),
  valid_user_reqID,
  async function (req, res, next) {
    try {// access the ChangePassword function
      const logger = main.logger

      const logger_all = main.logger_all;

      const result = await Update_logo_change.LogoUpdate(req);

      result['request_id'] = req.body.request_id;

      //update api log for failure response
      if (result.response_code == 0) {
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }
      else {
        //Otherwise update api log with success response
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }

      logger.info("[API RESPONSE] " + JSON.stringify(result))
      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// Update On Boarding - end

// Update User Status -start
router.put(
  "/update_status",
  validator.body(UpdateUserStatusValidation),
  valid_user_reqID,
  async function (req, res, next) {
    try {// access the ChangePassword function
      const logger = main.logger

      const logger_all = main.logger_all;

      const result = await Update_Status.UpdateStatus(req);

      result['request_id'] = req.body.request_id;

      //update api log for failure response
      if (result.response_code == 0) {
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'F',response_date = CURRENT_TIMESTAMP, response_comments = '${result.response_msg}' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }
      else {
        //Otherwise update api log with success response
        logger.silly("[update query request] : " + `UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        const update_api_log = await db.query(`UPDATE api_log SET response_status = 'S',response_date = CURRENT_TIMESTAMP, response_comments = 'Success' WHERE request_id = '${req.body.request_id}' AND response_status = 'N'`);
        logger.silly("[update query response] : " + JSON.stringify(update_api_log))
      }

      logger.info("[API RESPONSE] " + JSON.stringify(result))
      res.json(result);
    } catch (err) {// any error occurres send error response to client
      console.error(`Error while getting data`, err.message);
      next(err);
    }
  }
);
// Update User Status - end


module.exports = router;
