/*
This api has chat API functions which is used to connect the mobile chat.
This page is act as a Backend page which is connect with Node JS API and PHP Frontend.
It will collect the form details and send it to API.
After Update the response from API, send it back to Frontend.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const db = require("../../db_connect/connect");
require("dotenv").config();
const main = require('../../logger');
// onboarding_form_list - start
async function onboarding_form_list(req) {
	const logger_all = main.logger_all
	const logger = main.logger
	try {

		// query parameters
		logger_all.info("[onboarding_form_list query parameters] : " + JSON.stringify(req.body));

		// Get User Personal Information
		const active_users = `SELECT usr.user_id, usr.user_master_id, usr.user_name, usr.user_email, usr.user_mobile, usmst.user_type, usr.user_approval_status FROM user_management usr, user_master usmst where usr.user_master_id = usmst.user_master_id and usr.user_id != usr.parent_id and usr.user_approval_status not in ('N') ORDER BY usr.user_approval_status desc, usr.user_id Desc`
		logger_all.info("[select query request] : " + active_users);
		const active_users_result = await db.query(active_users);
		logger_all.info("[select query response] : " + JSON.stringify(active_users_result))

		// if the get total response length is not available to send the no available data.otherwise it will be return the total_response dashboard today details.
		if (active_users_result.length > 0) {
			return {
				response_code: 1, response_status: 200, response_msg: 'Success', num_of_rows: active_users_result.length, report: active_users_result
			};
		} else {
			return { response_code: 0, response_status: 204, response_msg: 'No Data Available' };
		}

	}
	catch (e) {// any error occurres send error response to client
		logger_all.info("[onboarding_form_list failed response] : " + e)
		return { response_code: 0, response_status: 201, response_msg: 'Error occured' };
	}
}
// 	onboarding_form_list - end

// using for module exporting
module.exports = {
	onboarding_form_list
}