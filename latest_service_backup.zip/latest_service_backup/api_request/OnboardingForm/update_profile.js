const db = require("../../db_connect/connect");
require("dotenv").config();
const main = require('../../logger');

// UpdateOnBoarding - start
async function UpdateOnBoarding(req) {
    const logger_all = main.logger_all;
    const logger = main.logger;
    try {
        // personal informations are update 
        const user_id = req.body.user_id;
        const user_email = req.body.user_email;
        const user_mobile = req.body.user_mobile;
        const txt_address = req.body.txt_address;
        const txt_city = req.body.txt_city;
        const txt_state = req.body.txt_state;
        const txt_country = req.body.txt_country;

        const user_company_name = req.body.user_company_name;
        const user_company_type = req.body.user_company_type;
        const user_registration_id = req.body.user_registration_id;
        const user_company_email = req.body.user_company_email;
        const user_company_mobile = req.body.user_company_mobile;
        const user_gst_id = req.body.user_gst_id;
        const user_aadhaar_no = req.body.user_aadhaar_no;
        const user_pan_no = req.body.user_pan_no;
        const user_bank_no = req.body.user_bank_no;
        const user_ifsc = req.body.user_ifsc;
        const user_company_labour = req.body.user_company_labour;
        const user_operating_llc = req.body.user_operating_llc;
        const user_company_insurance = req.body.user_company_insurance;
        const user_partnership = req.body.user_partnership;
        const user_transaction = req.body.user_transaction;
        const user_company_address = req.body.user_company_address;
        const user_company_city = req.body.user_company_city;
        const user_company_state = req.body.user_company_state;
        const user_company_country = req.body.user_company_country;
        const user_tan_no = req.body.user_tan_no;
        const upload_document_name = req.body.upload_document_name;
        const documents_name = ['user_cmpy_labour_doc', 'user_operating_llc_doc', 'user_company_insurance', 'user_partnership_doc'];
console.log(upload_document_name);
        let user_management_update = {};
        let user_management_details_update = {};

        // Add fields to the object only if they exist on User management Using on Update
        if (user_email) user_management_update.user_email = user_email;
        if (user_mobile) user_management_update.user_mobile = user_mobile;
        if (txt_address) user_management_update.user_address = txt_address;
        if (txt_city) user_management_update.user_city = txt_city;
        if (txt_state) user_management_update.user_state = txt_state;
        if (txt_country) user_management_update.user_country = txt_country;

        // Add fields to the object only if they exist on User management details Using on Update
        if (user_company_name) user_management_details_update.user_company_name = user_company_name;
        if (user_company_type) user_management_details_update.user_company_type = user_company_type;
        if (user_registration_id) user_management_details_update.user_registration_id = user_registration_id;
        if (user_company_email) user_management_details_update.user_company_email = user_company_email;
        if (user_company_mobile) user_management_details_update.user_company_mobile = user_company_mobile;
        if (user_gst_id) user_management_details_update.user_gst_id = user_gst_id;
        if (user_aadhaar_no) user_management_details_update.user_aadhaar_no = user_aadhaar_no;
        if (user_pan_no) user_management_details_update.user_pan_no = user_pan_no;
        if (user_tan_no) user_management_details_update.user_tan_no = user_tan_no;
        if (user_bank_no) user_management_details_update.user_bank_no = user_bank_no;
        if (user_ifsc) user_management_details_update.user_ifsc = user_ifsc;
        if (user_company_labour) user_management_details_update.user_company_labour = user_company_labour;
        if (user_operating_llc) user_management_details_update.user_operating_llc = user_operating_llc;
        if (user_company_insurance) user_management_details_update.user_company_insurance = user_company_insurance;
        if (user_partnership) user_management_details_update.user_partnership = user_partnership;
        if (user_transaction) user_management_details_update.user_transaction = user_transaction;
        if (user_company_address) user_management_details_update.user_company_address = user_company_address;
        if (user_company_city) user_management_details_update.user_company_city = user_company_city;
        if (user_company_state) user_management_details_update.user_company_state = user_company_state;
        if (user_company_country) user_management_details_update.user_company_country = user_company_country;

        logger_all.info("[UpdateOnBoarding query parameters] : " + JSON.stringify(req.body));

        if (Object.keys(user_management_update).length > 0) {
            const setClause = Object.entries(user_management_update)
                .map(([key]) => `${key} = ?`)
                .join(', ');

            const values = Object.values(user_management_update);
            const user_management = `SELECT * FROM user_management WHERE user_id = ?`;
            logger_all.info("[select query request] : " + user_management);
            const user_management_result = await db.query(user_management, [user_id]);

            logger_all.info("[select query response] : " + JSON.stringify(user_management_result));

            if (user_management_result.length > 0) {
                const update_user_management = `UPDATE user_management SET ${setClause} WHERE user_id = ?`;
                logger_all.info("[update query request] : " + update_user_management);
                const update_result = await db.query(update_user_management, [...values, user_id]);
                logger_all.info("[update Profile query response] : " + JSON.stringify(update_result));
            } else {
                return { response_code: 0, response_status: 201, response_msg: 'Inactive user.' };
            }
        }


        if ( upload_document_name && upload_document_name.length > 0) {
            for (let i = 0; i < upload_document_name.length; i++) {
                const documentName = documents_name[i];
                logger_all.info("[Document Name] : " + documentName);
                

                const upload_docs = upload_document_name[i];
                logger_all.info("[Document Name] : " + upload_docs);
    
                // Extracting the actual document name from the formatted string
                const FileName = upload_docs.split(': ')[1];
    
                const get_user_documents = `SELECT * FROM user_documents WHERE user_document = '${documentName}' AND user_id = '${user_id}'`;
                logger_all.info("[select query request] : " + get_user_documents);
    
                try {
                    const get_user_documents_results = await db.query(get_user_documents);
                    logger_all.info("[select query response] : " + JSON.stringify(get_user_documents_results));
    
                    if (get_user_documents_results.length > 0) {
                        const update_user_documents = `UPDATE user_documents SET user_doc_title = ?, user_document = ?, user_doc_status = 'Y', user_doc_entry_date = CURRENT_TIMESTAMP WHERE user_document = ? AND user_id = ?`;
                        logger_all.info("[update query request] : " + update_user_documents);
    
                        const update_user_documents_list = await db.query(update_user_documents, [documentName, FileName, FileName, user_id]);
                        logger_all.info("[update query response] : " + JSON.stringify(update_user_documents_list));
                    } else {
                        const insert_web_announcement = `INSERT INTO user_documents (user_doc_id, user_id, user_doc_title, user_document, user_doc_status, user_doc_entry_date) VALUES (NULL, ?, ?, ?, 'Y', CURRENT_TIMESTAMP)`;
                        logger_all.info("[insert query request] : " + insert_web_announcement);
    
                        const insert_result = await db.query(insert_web_announcement, [user_id, documentName, FileName]);
                        logger_all.info("[insert query response] : " + JSON.stringify(insert_result));
                    }
                } catch (error) {
                    logger_all.error("[Database error] : " + error);
                }
            }
        }

        const get_user_management_details = `SELECT * FROM user_management_details WHERE user_id = ?`;
        logger_all.info("[select query request] : " + get_user_management_details);
        const get_user_management_details_results = await db.query(get_user_management_details, [user_id]);
        logger_all.info("[select query response] : " + JSON.stringify(get_user_management_details_results));

        if (get_user_management_details_results.length > 0) {
            let setClause = [];
            let values = [];
            let i = 1;

            for (const [key, value] of Object.entries(user_management_details_update)) {
                setClause.push(`${key} = ?`);
                values.push(value);
                i++;
            }

            if (setClause.length > 0) {
                values.push(user_id); // Add user_id to the values array
                const updateQuery = `UPDATE user_management_details SET ${setClause.join(', ')} WHERE user_id = ?`;
                logger_all.info("[update query request] : " + updateQuery);
                try {
                    const update_user_documents_list = await db.query(updateQuery, values);
                    logger_all.info("[update query response] : " + JSON.stringify(update_user_documents_list));
                } catch (error) {
                    logger_all.error("[update query error] : " + error.message);
                }
            } else {
                logger_all.info("No fields to update");
            }
        } else {
            const insert_web_announcement = `INSERT INTO user_management_details (user_id, user_company_name, user_company_type, user_registration_id, user_company_email, user_company_mobile, user_gst_id, user_aadhaar_no, user_pan_no,user_tan_no, user_bank_no, user_ifsc, user_company_labour, user_operating_llc, user_company_insurance, user_partnership, user_transaction, user_company_address, user_company_city, user_company_state, user_company_country, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Y', CURRENT_TIMESTAMP)`;
            logger_all.info("[insert query request] : " + insert_web_announcement);
            const insert_result = await db.query(insert_web_announcement, [user_id, user_company_name, user_company_type, user_registration_id, user_company_email, user_company_mobile, user_gst_id, user_aadhaar_no, user_pan_no, user_tan_no,user_bank_no, user_ifsc, user_company_labour, user_operating_llc, user_company_insurance, user_partnership, user_transaction, user_company_address, user_company_city, user_company_state, user_company_country]);
            logger_all.info("[insert query response] : " + JSON.stringify(insert_result));
        }


        return { response_code: 1, response_status: 200, response_msg: 'Success' };

    } catch (e) {
        logger_all.info("[UpdateOnBoarding failed response] : " + e);
        return { response_code: 0, response_status: 201, response_msg: 'Error occurred' };
    }
}

// using for module exporting
module.exports = {
    UpdateOnBoarding
};
