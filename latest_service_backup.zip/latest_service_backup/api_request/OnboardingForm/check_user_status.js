/*
This api has chat API functions which is used to connect the mobile chat.
This page is act as a Backend page which is connect with Node JS API and PHP Frontend.
It will collect the form details and send it to API.
After get the response from API, send it back to Frontend.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const db = require("../../db_connect/connect");
require("dotenv").config();
const main = require('../../logger');
// CheckUserDetails - start
async function CheckUserDetails(req) {
	const logger_all = main.logger_all
	const logger = main.logger
	try {

		// get body values
		const check_user_id = req.body.check_user_id;

		// query parameters
		logger_all.info("[CheckUserDetails query parameters] : " + JSON.stringify(req.body));

		// to get the web_announcement details
		const get_users = `SELECT usr.user_id, usr.user_name FROM user_management usr where usr.user_id = '${check_user_id}' and usr.usr_mgt_status = 'Y' and usr.user_approval_status = 'W' ORDER BY usr.user_id ASC`;

		logger_all.info("[select query request] : " + get_users);
		const get_users_list = await db.query(get_users);

		logger_all.info("[select query response] : " + JSON.stringify(get_users_list))

		// if the web_announcement length is coming to get the web_announcement details.otherwise to send the no data available message.
		if (get_users_list.length == 0) {
			return { response_code: 0, response_status: 204, response_msg: 'No data available' };
		}
		else {
			return { response_code: 1, response_status: 200, num_of_rows: get_users_list.length, response_msg: 'Success', result: get_users_list, num_of_rows: get_users_list.length };
		}
	}
	catch (e) {// any error occurres send error response to client
		logger_all.info("[CheckUserDetails failed response] : " + e)
		return { response_code: 0, response_status: 201, response_msg: 'Error occured' };
	}
}
// 	CheckUserDetails - end

// using for module exporting
module.exports = {
	CheckUserDetails
}