/*
This api has chat API functions which is used to connect the mobile chat.
This page is act as a Backend page which is connect with Node JS API and PHP Frontend.
It will collect the form details and send it to API.
After Update the response from API, send it back to Frontend.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const db = require("../../db_connect/connect");
require("dotenv").config();
const main = require('../../logger');
// Get_User_Details - start
async function Get_User_Details(req) {
	const logger_all = main.logger_all
	const logger = main.logger
	try {
		// Get all the req data
		const view_user_id = req.body.view_user_id;
		
		let total_response = [];

		// query parameters
		logger_all.info("[Get_User_Details query parameters] : " + JSON.stringify(req.body));

		// Get User Personal Information
		const active_users = `SELECT usr.*, umas.*, cntr.id cntrid, cntr.name cntrname, stat.id statid,stat.name statname, city.id cityid, city.name cityname FROM user_management usr left join user_master umas on umas.user_master_id = usr.user_master_id left join master_countries cntr on cntr.id = usr.user_country left join master_states stat on stat.id = usr.user_state and stat.country_id = cntr.id left join master_cities city on city.id = usr.user_city and city.state_id = stat.id where usr.user_id = '${view_user_id}' and usr.usr_mgt_status = 'Y' ORDER BY usr.user_id ASC`
		logger_all.info("[select query request] : " + active_users);
		const active_users_result = await db.query(active_users);
		logger_all.info("[select query response] : " + JSON.stringify(active_users_result))
		total_response.push(active_users_result);

		// Get User Company Information
		let get_announcement = `SELECT usr.*, cntr.id cntrid, cntr.name cntrname, stat.id statid,stat.name statname, city.id cityid, city.name cityname from user_management_details usr left join master_countries cntr on cntr.id = usr.user_company_country left join master_states stat on stat.id = usr.user_company_state and stat.country_id = cntr.id left join master_cities city on city.id = usr.user_company_city and city.state_id = stat.id where usr.user_id = '${view_user_id}' ORDER BY usr.user_id ASC`;
		logger_all.info("[select query request] : " + get_announcement);
		let get_announcement_result = await db.query(get_announcement);
		logger_all.info("[select query response] : " + JSON.stringify(get_announcement_result))
		total_response.push(get_announcement_result);

		//    get User Documents
		const total_week_data = `SELECT * FROM user_documents where user_id = '${view_user_id}'`;
		logger_all.info("[select query request] : " + total_week_data);
		const total_week_data_result = await db.query(total_week_data);
		logger_all.info("[select query response] : " + JSON.stringify(total_week_data_result))
		total_response.push(total_week_data_result);


		// if the get total response length is not available to send the no available data.otherwise it will be return the total_response dashboard today details.
		if (total_response.length > 0) {
			return {
				response_code: 1, response_status: 200, response_msg: 'Success', num_of_rows: total_response.length, report: total_response
			};
		} else {
			return { response_code: 0, response_status: 204, response_msg: 'No Data Available' };
		}

	}
	catch (e) {// any error occurres send error response to client
		logger_all.info("[Get_User_Details failed response] : " + e)
		return { response_code: 0, response_status: 201, response_msg: 'Error occured' };
	}
}
// 	Get_User_Details - end

// using for module exporting
module.exports = {
	Get_User_Details
}