/*
This api has chat API functions which is used to connect the mobile chat.
This page is act as a Backend page which is connect with Node JS API and PHP Frontend.
It will collect the form details and send it to API.
After Update the response from API, send it back to Frontend.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const db = require("../../db_connect/connect");
require("dotenv").config();
const main = require('../../logger');
// UpdateStatus - start
async function UpdateStatus(req) {
    const logger_all = main.logger_all
    const logger = main.logger
    
    try {
        // personal informations are update 
        const user_id = req.body.user_id;
        const select_userid = req.body.select_userid;
        const parent_id = req.body.parent_id;
        const usr_mgt_status = req.body.usr_mgt_status;

      
                if (user_id && parent_id && usr_mgt_status && select_userid ) {

                    // Update the user_documents details
                    const update_user_documents = `UPDATE user_management SET usr_mgt_status = '${usr_mgt_status}' WHERE parent_id = '${parent_id}' AND user_id = '${user_id}'`;
                    logger_all.info("[update query request] : " + update_user_documents);
                    const update_user_documents_list = await db.query(update_user_documents, [upload_document_name, documentName, documentName, user_id]);
                    logger_all.info("[update query response] : " + JSON.stringify(update_user_documents_list));

                } 

                if(select_userid && user_id && !usr_mgt_status && !parent_id) {

                    // Insert new document details
                    const insert_admin_approval = `INSERT INTO reseller_admin_approval VALUES (NULL, '${select_userid}', '${user_id}', 'Reseller Account - Approval', 'V', CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)`;
                    logger_all.info("[insert query request] : " + insert_admin_approval);
                    const insert_admin_approval_result = await db.query(insert_admin_approval);
                    logger_all.info("[insert query response] : " + JSON.stringify(insert_admin_approval_result));
                }
            
        
        // if the web_announcement length is coming to Update the web_announcement details.otherwise to send the no data available message.
            return { response_code: 1, response_status: 200, response_msg: 'Success' };
    }
    catch (e) {// any error occurres send error response to client
        logger_all.info("[UpdateStatus failed response] : " + e)
        return { response_code: 0, response_status: 201, response_msg: 'Error occured' };
    }
}
// 	UpdateStatus - end

// using for module exporting
module.exports = {
    UpdateStatus
}