/*
It is used to one of which is user input validation.
Announcement function to validate the user.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const Joi = require("@hapi/joi");
// To declare Announcement object 
const Announcement = Joi.object().keys({
  // Object Properties are define
  announcement_msg: Joi.string().required().label("Announcement Msg"),
  announcement_expirydt: Joi.string().optional().label("Announcement Expiry Date"),
  announcement_status: Joi.string().required().label("Announcement status"),
  announcement_id: Joi.string().optional().label("Announcement Id"),
  request_id: Joi.string().required().label("Request Id")

}).options({ abortEarly: false });
// To exports the Announcement module
module.exports = Announcement