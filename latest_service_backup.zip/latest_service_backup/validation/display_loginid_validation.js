/*
It is used to one of which is user input validation.
UsersList function to validate the user.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const Joi = require("@hapi/joi");
// To declare UsersList object 
const UsersList = Joi.object().keys({
  // Object Properties are define
  user_id: Joi.string().optional().label("User Id"),
  user_name: Joi.string().optional().label("User Name"),

}).options({ abortEarly: false });
// To exports the UsersList module
module.exports = UsersList

