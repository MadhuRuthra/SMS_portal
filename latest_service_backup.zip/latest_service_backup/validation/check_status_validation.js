/*
It is used to one of which is user input validation.
Announcement function to validate the user.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const Joi = require("@hapi/joi");
// To declare Announcement object 
const CheckStatus = Joi.object().keys({
  // Object Properties are define
  check_user_id: Joi.string().required().label("Check User Id"),
}).options({ abortEarly: false });
// To exports the Announcement module
module.exports = CheckStatus