/*
It is used to one of which is user input validation.
StateList function to validate the user.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const Joi = require("@hapi/joi");
// To declare StateList object 
const Update_Logo = Joi.object().keys({
  // Object Properties are define
  cmpy_logo_name: Joi.string().optional().label("cmpy Logo name"),

}).options({ abortEarly: false });
// To exports the StateList module
module.exports = Update_Logo