/*
It is used to one of which is user input validation.
StateList function to validate the user.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const Joi = require("@hapi/joi");
// To declare StateList object 
const Update_userstatus = Joi.object().keys({
  // Object Properties are define
  user_id: Joi.string().optional().label("user id"),
  select_userid: Joi.string().optional().label("Select user id"),
  parent_id: Joi.string().optional().label("Parent id"),
  usr_mgt_status: Joi.string().optional().label("Usr mgt status"),

}).options({ abortEarly: false });
// To exports the StateList module
module.exports = Update_userstatus