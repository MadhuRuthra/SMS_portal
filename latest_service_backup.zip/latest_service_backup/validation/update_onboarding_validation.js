/*
It is used to one of which is user input validation.
UserDetails function to validate the user.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const Joi = require("@hapi/joi");
// To declare UserDetails object 
const UserDetails = Joi.object().keys({
  // Object Properties are define
  request_id: Joi.string().required().label("Request Id"),
  user_id: Joi.string().optional().label("User Id"),
  user_email: Joi.string().optional().label("User Email"),
  user_mobile: Joi.string().optional().label("User Mobile"),
  txt_address: Joi.string().optional().label("Txt Address"),
  txt_city: Joi.string().optional().label("Txt City"),
  txt_state: Joi.string().optional().label("Txt State"),
  txt_country: Joi.string().optional().label("TXT Country"),
  user_company_name: Joi.string().optional().label("User Company Name"),
  user_company_type: Joi.string().optional().label("User Company type"),
  user_registration_id: Joi.string().optional().label("User Registration Id"),
  user_company_email: Joi.string().optional().label("User Company Email"),
  user_company_mobile: Joi.string().optional().label("User Company Mobile"),
  user_gst_id: Joi.string().optional().label("User Gst Id"),
  user_aadhaar_no: Joi.string().optional().label("User Aadhar No"),
  user_pan_no: Joi.string().optional().label("User Pan No"),
  user_tan_no: Joi.string().optional().label("User Tan No"),
  user_bank_no: Joi.string().optional().label("User Bank No"),
  user_ifsc: Joi.string().optional().label("User IFSC"),
  user_company_labour: Joi.string().optional().label("User Company labour"),
  user_operating_llc: Joi.string().optional().label("User Operating LLc"),
  user_company_insurance: Joi.string().optional().label("User Company Insurance"),
  user_partnership: Joi.string().optional().label("User Partnership "),
  user_transaction: Joi.string().optional().label("User Transaction"),
  user_company_address: Joi.string().optional().label("User Company Address"),
  user_company_city: Joi.string().optional().label("User Company City"),
  user_company_state: Joi.string().optional().label("User Country State"),
  user_company_country: Joi.string().optional().label("User Company Address"),
  upload_document_name: Joi.array().optional().label("Upload Document Name"),

}).options({ abortEarly: false });
// To exports the UserDetails module
module.exports = UserDetails