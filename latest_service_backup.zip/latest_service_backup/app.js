/*
API that allows your frontend to communicate with your backend server (Node.js) for processing and retrieving data.
To access a MySQL database with Node.js and can be use it.
This is a main page for starting API the process.This page to routing the subpages page and then process are executed.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const https = require("https");
const express = require("express");
const dotenv = require('dotenv');
dotenv.config();
// const router = express.Router();
var cors = require("cors");
var axios = require('axios');
const nodemailer = require('nodemailer');

const mime = require('mime');
// Database Connections
const app = express();
const port = 10017;
const db = require("./db_connect/connect");
const dynamic_db = require("./db_connect/dynamic_connect");

const validator = require('./validation/middleware')

const bodyParser = require('body-parser');
const fs = require('fs');
const log_file = require('./logger')
const logger = log_file.logger;
const logger_all = log_file.logger_all;


const httpServer = https.createServer(app);
const io = require('socket.io')(httpServer, {
	cors: {
		origin: "*",
	},
});

// Process Validations
const Logout = require("./logout/route");
const Login = require("./login/route");
const MasterList = require("./api_request/masters_list/list_route");
const List = require("./api_request/list/list_route");
const valid_user = require("./validation/valid_user_middleware");
const dashboard = require("./api_request/dashboard/dashboard_route");
const web_announcement = require("./api_request/WebAnnouncement/route");
const onboardingform = require("./api_request/OnboardingForm/route");
const DLT = require("./api_request/dlt/route");

// Current Date and Time
// var today = new Date().toLocaleString("en-IN", {timeZone: "Asia/Kolkata"});
var day = new Date();

// Log file Generation based on the current date
var util = require('util');
var exec = require('child_process').exec;

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(
	express.urlencoded({
		extended: true,
		limit: '50mb'
	})
);

// Allows you to send emits from express
app.use(function (request, response, next) {
	request.io = io;
	next();
});

app.get("/", async (req, res) => {
	console.log(day)
	res.json({ message: "okkkk" });
});
function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
app.use(bodyParser.json());

// API initialzation
app.use("/login", Login);
app.use("/logout", Logout);
app.use("/", MasterList);
app.use("/list", List);
app.use("/", dashboard);
app.use("/", web_announcement);
app.use("/", onboardingform);
app.use("/", DLT);

// to listen the port in using the localhost
app.listen(port, () => {
	logger_all.info(`App started listening at http://localhost:${port}`);
});

// module.exports.logger = logger;

//  to listen the port in using the server

// httpServer.listen(port, function (req, res) {
// 	logger_all.info("Server started at port " + port);
// });

