/*
API that allows your frontend to communicate with your backend server (Node.js) for processing and retrieving data.
To access a MySQL database with Node.js and can be use it.
This page is used in login functions which is used in login.

Version : 1.0
Author : Madhubala (YJ0009)
Date : 05-Jul-2023
*/
// Import the required packages and libraries
const db = require("../db_connect/connect");
const md5 = require("md5")
const main = require('../logger')
require("dotenv").config();
const dynamic_db = require("../db_connect/dynamic_connect");
const jwt = require('jsonwebtoken');
const { response } = require("express");
const nodemailer = require('nodemailer');

// portal login Function - Start
async function api_login(req) {

  const logger = main.logger
  const logger_all = main.logger_all

  // To get current Date and Time
  const day = new Date();
  const today_date = day.getFullYear() + '-' + (day.getMonth() + 1) + '-' + day.getDate();
  const today_time = day.getHours() + ":" + day.getMinutes() + ":" + day.getSeconds();
  const current_date = today_date + ' ' + today_time;

  // declare the variables
  let user_id;
  // get all the req data
  const txt_username = req.body.txt_username;
  const txt_password = md5(req.body.txt_password);
  const header_json = req.headers;
  const ip_address = header_json['x-forwarded-for'];

  logger.info("[API REQUEST] " + req.originalUrl + " - " + JSON.stringify(req.body) + " - " + JSON.stringify(req.headers) + " - " + ip_address)
  logger_all.info("[API REQUEST] " + req.originalUrl + " - " + JSON.stringify(req.body) + " - " + JSON.stringify(req.headers) + " - " + ip_address)

  try { // To check the login_id if the user_management table already exists are not

      // query parameters
      logger_all.info("[Dashboard query parameters] : " + JSON.stringify(req.body));

    const slt_user = `SELECT * FROM user_management where login_id = '${txt_username}' and usr_mgt_status in ('N', 'Y') ORDER BY user_id ASC`;
    logger_all.info("[select query request] : " + slt_user)
    const sql_login = await db.query(slt_user);

    // If any sql_login length are availble to send the error message Invalid User. Kindly try again with the valid User!
    if (sql_login.length == 0) {
      // Failed [Invalid User] - call_index_signin Sign in function
      logger_all.info(": [call_index_signin] Failed - Invalid User. Kindly try again with the valid User!");
      return { response_code: 0, response_status: 201, response_msg: "Invalid User. Kindly try again with the valid User!" };
    } else { // Otherwise to check login_id and login_password and usr_mgt_status

      const check_password = `SELECT * FROM user_management where login_id = '${txt_username}' and login_password =  '${txt_password}' and usr_mgt_status in ('N', 'Y') ORDER BY user_id ASC`;

      logger_all.info("[select query request] : " + check_password);
      const response_result = await db.query(check_password);
      // If response_result length are available to send the message in Invalid Password. Kindly try again with the valid details!
      if (response_result.length <= 0) {
        // Failed [Invalid Password] - call_index_signin Sign in function
        logger_all.info(": [call_index_signin] Failed  - Invalid Password. Kindly try again with the valid details!");
        return { response_code: 0, response_status: 201, response_msg: "Invalid Password. Kindly try again with the valid details!" };
      } else {
        // Otherwise the process are continue to create the JWT token
        user_id = response_result[0].user_id;
        const user =
        {
          username: req.body.txt_username,
          user_password: req.body.txt_password,
        }
        // Sign the jwt 
        const accessToken_1 = jwt.sign(user, process.env.ACCESS_TOKEN_SECRET, {
          expiresIn: process.env.ONEWEEK

        });

        process.env['TOKEN_SECRET'] = "Bearer " + accessToken_1;
        const bearer_token = process.env.TOKEN_SECRET;

        // To update the bearer token in the usermanagement table
        const update_user = `UPDATE user_management SET bearer_token = '${bearer_token}' WHERE user_id = '${user_id}'`;
        logger_all.info("[Update query request] : " + update_user);
        const token = await db.query(update_user);
        logger_all.info("[Update query Response] : " + JSON.stringify(token));

        // To Login Success - If the user_log_status is 'I' and login date are already exists are not.
        const user_log = `SELECT user_id,user_log_status,login_date FROM user_log where user_id ='${response_result[0].user_id}' and user_log_status = 'I' and date(login_date) ='${today_date}'`;

        logger_all.info("[select query request] : " + user_log);

        const check_login = await db.query(user_log);

        if (check_login.length == 0) {
          // check login length is 0 .the process was continue.To insert the user_log table in the values
          const insert_usr_log = `INSERT INTO user_log VALUES(NULL, '${response_result[0].user_id}', '${ip_address}', '${current_date}', '${current_date}', NULL, 'I', '${current_date}')`;

          logger_all.info("[insert query request] : " + insert_usr_log);
          const insert_login = await db.query(insert_usr_log);
          // Json Push
          response_result[0]['bearer_token'] = bearer_token;
          // To send the Success message and user details in the user
          logger_all.info(": [call_index_signin] Success ");
          return { response_code: 1, response_status: 200, response_msg: "Success", login_time: current_date, response_result, num_of_rows: response_result.length };

        }
        else { // Otherwise to update the userlog table to set the value is user_log_status = 'O' and login date
          const update_log = `UPDATE user_log SET user_log_status = 'O', logout_time = '${current_date}' WHERE user_id = '${response_result[0].user_id}' AND user_log_status = 'I' AND login_date = '${today_date}'`
          logger_all.info("[update query request] : " + update_log);

          const update_logout = await db.query(update_log);

          // And user_log table to insert the details.

          const user_log_insert = `INSERT INTO user_log VALUES(NULL, '${response_result[0].user_id}', '${ip_address}', '${current_date}', '${current_date}', NULL, 'I', '${current_date}')`;

          logger_all.info("[insert query request] : " + user_log_insert);
          const insert_login = await db.query(user_log_insert);
          // Json Push
          response_result[0]['bearer_token'] = bearer_token;
          // To send the Success message and user details in the user
          logger_all.info(": [call_index_signin] Success ");
          return { response_code: 1, response_status: 200, response_msg: "Success", login_time: current_date, response_result, num_of_rows: response_result.length };
        }

      }
    }
  }
  catch (err) {
    // Failed - call_index_signin Sign in function
    logger_all.info(": [call_index_signin] Failed - " + err);
    return { response_code: 0, response_status: 201, response_msg: 'Error Occurred.' };
  }
}
//login Function - end


// signup - start
async function Signup(req) {
  const logger_all = main.logger_all;

  try {
    const {  user_name, user_email, user_mobile, txt_address, txt_city, txt_state, txt_country, loginid, parent_id, user_password } = req.body;
    let user_type = req.body.user_type;

    const user_password_hashed = md5(user_password);
    let ex_available_sms = 0, ex_allot_sms = 0;

    logger_all.info("[Dashboard query parameters] : " + JSON.stringify(req.body));

    let today = new Date();
    let oneYearValidity = new Date(today);
    oneYearValidity.setFullYear(oneYearValidity.getFullYear() + 1);
    let formattedToday = today.toISOString().replace('T', ' ').replace(/\.\d+Z$/, '');
    let formattedValidity = oneYearValidity.toISOString().replace('T', ' ').replace(/\.\d+Z$/, '');

    console.log("Today's Date:", formattedToday);
    console.log("One Year Validity:", formattedValidity);

    const check_username = `SELECT * FROM user_management WHERE login_id = '${user_name}' OR user_email = '${user_email}'`;
    logger_all.info("[signup - select query request] : " + check_username);
    let sql_stat = await db.query(check_username);
    logger_all.info("[signup - select query response] : " + JSON.stringify(sql_stat));

    if (sql_stat.length > 0) {
      logger_all.info("[signup] Failed - Client Name already used. Kindly try with some others!!");
      return {
        response_code: 0,
        response_status: 201,
        response_msg: "Client Name already used. Kindly try with some others!!"
      };
    } else {
      const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      let result = '';
      const charactersLength = characters.length;
      for (let i = 0; i < 32; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
      }

      let string = result.substring(0, 15);
      let apikey = string.toUpperCase();

      switch (user_type) {
        case "2":
          user_type = 2;
          break;
        default:
          user_type = 3;
          break;
      }

      const insert_users = `INSERT INTO user_management VALUES (NULL, '${user_type}', '${parent_id}', '${user_name}', '${apikey}', '${loginid}', '-', '${user_password_hashed}', '${user_email}', '${user_mobile}', '${txt_address}', '${txt_city}', '${txt_state}', '${txt_country}', '0', 'Y', CURRENT_TIMESTAMP, '1', 'W', NULL, NULL, NULL, NULL)`;
      logger_all.info("[signup - insert query request] : " + insert_users);

      const insert_user = await db.query(insert_users);
      logger_all.info("[signup - insert query response] : " + JSON.stringify(insert_user));
      const lastid = insert_user.insertId;

      const check_creditdebitacc = `SELECT usrcrdbt_id, allot_sms FROM user_credit_debit_account WHERE sms_route_id = '3' AND user_id = '1'`;
      logger_all.info("[signup - check_creditdebitacc query request] : " + check_creditdebitacc);

      const check_creditdebitacc_result = await db.query(check_creditdebitacc);
      logger_all.info("[signup - check_creditdebitacc query response] : " + JSON.stringify(check_creditdebitacc_result));

      if (check_creditdebitacc_result.length > 0) {
        ex_available_sms = check_creditdebitacc_result[0].allot_sms;
      }
      ex_allot_sms = ex_available_sms - 10;

      const insert_userscredit_acc = `INSERT INTO user_credit_debit_account VALUES (NULL, '3', '${lastid}', '1', '${formattedValidity}', '12', '${ex_allot_sms}', '0', '0', '10 SMS Credited by Super Admin', 'C', 'Y', CURRENT_TIMESTAMP)`;
      logger_all.info("[signup - insert_userscredit_acc query request] : " + insert_userscredit_acc);

      const insert_userscredit_acc_result = await db.query(insert_userscredit_acc);
      logger_all.info("[signup - insert_userscredit_acc query response] : " + JSON.stringify(insert_userscredit_acc_result));

      const reseller_insert = `INSERT INTO reseller_admin_approval VALUES (NULL, '${lastid}', '${parent_id}', 'Reseller Account - Approval', 'V', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`;
      logger_all.info("[signup - reseller_insert query request] : " + reseller_insert);

      const reseller_insert_result = await db.query(reseller_insert);
      logger_all.info("[signup - admin_dashboard_insert_result query response] : " + JSON.stringify(reseller_insert_result));

      const admin_dashboard_insert = `INSERT INTO admin_dashboard VALUES (NULL, '${lastid}', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'Y', CURRENT_TIMESTAMP)`;
      logger_all.info("[signup - admin_dashboard_insert_result query request] : " + admin_dashboard_insert);

      const admin_dashboard_insert_result = await db.query(admin_dashboard_insert);
      logger_all.info("[signup - admin_dashboard_insert_result query response] : " + JSON.stringify(admin_dashboard_insert_result));

      return {
        response_code: 1,
        response_status: 200,
        response_msg: 'Success',
      };
    }
  } catch (err) {
    logger_all.info("[signup] Failed - " + err.message);
    return {
      response_code: 0,
      response_status: 201,
      response_msg: err.message
    };
  }
}
// signup - end


// Reset Password start 
async function ResetPassword(req) {
  const logger_all = main.logger_all;
  const logger = main.logger;

  // Get current date and time
  const day = new Date();
  const today_date = day.getFullYear() + '-' + (day.getMonth() + 1) + '-' + day.getDate();
  const today_time = day.getHours() + ":" + day.getMinutes() + ":" + day.getSeconds();
  const current_date = today_date + ' ' + today_time;

  // Get all the req data
  const user_emailid = req.body.user_emailid;
  const request_id = req.body.request_id;
  const header_json = req.headers;
  const ip_address = header_json['x-forwarded-for'];

  logger.info("[API REQUEST] " + req.originalUrl + " - " + JSON.stringify(req.body) + " - " + JSON.stringify(req.headers) + " - " + ip_address);
  logger_all.info("[API REQUEST] " + req.originalUrl + " - " + JSON.stringify(req.body) + " - " + JSON.stringify(req.headers) + " - " + ip_address);

  try {

    const reset_pass = `SELECT * FROM user_management WHERE user_email = '${user_emailid}' AND usr_mgt_status IN ('Y') ORDER BY user_id ASC`;
    logger_all.info("[select query request] : " + reset_pass);
    const sql_stat = await db.query(reset_pass);
    logger_all.info("[select query response] : " + JSON.stringify(sql_stat));

    if (sql_stat.length == 0) {
      logger_all.info(": [Reset Password] Failed - Invalid Email ID. Kindly try again!!");
      return { response_code: 0, response_status: 201, response_msg: "Invalid Email ID. Kindly try again!!", request_id: req.body.request_id };
    } else {
      const user_id = sql_stat[0].user_id;

      const passwordvalue = new Set();

      function generateResetPassword() {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let reset_password;

        do {
          reset_password = '';
          for (let i = 0; i < 10; i++) {
            const randomIndex = Math.floor(Math.random() * characters.length);
            reset_password += characters.charAt(randomIndex);
          }
        } while (passwordvalue.has(reset_password));

        passwordvalue.add(reset_password);
        return reset_password;
      }

      const get_resetpassword = generateResetPassword();
      logger_all.info("[Reset Password] : " + get_resetpassword);

      const update_password = `UPDATE user_management SET login_password = '${md5(get_resetpassword)}' WHERE user_id = '${user_id}'`;
      logger_all.info("[Update query request] : " + update_password);
      const set_resetresult = await db.query(update_password);
      logger_all.info("[Update query response] : " + JSON.stringify(set_resetresult));

      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'suhasini.r@yeejai.com', // Your email address
          pass: 'cicauzxsnivlvhvs' // Your email password or app-specific password
        }
      });

      const mailOptions = {
        from: 'suhasini.r@yeejai.com', // Sender's email address and name
        to: user_emailid, // Recipient's email addresses separated by commas
        subject: 'Password reset for " Simply Reach Reg.', // Email subject
        text: `Dear User,\n\nWelcome to Simply Reach \nYour Email ID: ${user_emailid}\n New Password: ${get_resetpassword}\n\n\n By,\n\n\n Simply Reach Team`
      };

      return new Promise((resolve, reject) => {
        transporter.sendMail(mailOptions, async (error, info) => {
          if (error) {
            logger_all.info('Error occurred: Mail cannot be sent. Kindly check!!', error);
            return resolve({ response_code: 0, response_status: 201, response_msg: 'Mail cannot be sent. Kindly check!!' });
          } else {
            logger_all.info('Email sent: New password sent to your email. Kindly verify!!', info.response);
            return resolve({ response_code: 1, response_status: 200, response_msg: 'New password sent to your email. Kindly verify!!', request_id: req.body.request_id });
          }
        });
      });
    }

  } catch (err) {
    logger_all.info(": [Reset Password] Failed - " + err.message);
    return { response_code: 0, response_status: 201, response_msg: 'Error occurred.', request_id: req.body.request_id };
  }
}

// Reset Password end


// using for module exporting
module.exports = {
  api_login,
  Signup,  
  ResetPassword

};
